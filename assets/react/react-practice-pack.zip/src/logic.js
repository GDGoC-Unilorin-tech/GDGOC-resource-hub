export const initialFilters = { query: '', category: 'all', sort: 'original' };
export function filtersReducer(state, action) {
 switch (action.type) {
  case 'query': return { ...state, query: action.value };
  case 'category': return { ...state, category: action.value };
  case 'sort': return { ...state, sort: action.value };
  case 'reset': return { ...initialFilters };
  default: return state;
 }
}
export function validProjects(value) {
 if (!Array.isArray(value)) return false;
 const ids = new Set();
 for (const item of value) {
  if (!item || typeof item !== 'object' || typeof item.id !== 'string' || !item.id.trim() || ids.has(item.id) || typeof item.title !== 'string' || !item.title.trim() || !['web','design'].includes(item.category)) return false;
  ids.add(item.id);
 }
 return true;
}
export function selectProjects(projects, {query, category, sort}) {
 const matches = projects.filter(p => (category === 'all' || p.category === category) && p.title.toLowerCase().includes(query.trim().toLowerCase()));
 return sort === 'title' ? [...matches].sort((a,b) => a.title.localeCompare(b.title)) : matches;
}
