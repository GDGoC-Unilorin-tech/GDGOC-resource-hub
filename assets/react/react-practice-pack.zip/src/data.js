export const projects = [
 {id:'profile', title:'Personal profile', category:'web'},
 {id:'planner', title:'Study planner', category:'web'},
 {id:'poster', title:'Community poster', category:'design'}
];
