Original course practice assets. Reuse and adapt for learning. Images: study-wide 960x540, study-small 480x270, study-tall 480x640. Video: silent six-second Learn/Practise/Build animation. The VTT describes visual stages; real spoken media also needs speech/sound captions.

Copy images/ and media/ into your project. Serve over HTTP to test captions. If Python is installed, run py -m http.server 8000 (Windows) or python3 -m http.server 8000 (macOS/Linux) from the folder, then open http://localhost:8000. Alternatively use an editor preview server.
