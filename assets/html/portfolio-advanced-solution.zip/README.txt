HTML portfolio: advanced suggested implementation

This is one valid approach, not the only solution. Attempt the brief before comparing.
Extract the whole folder. Open index.html. For caption tests, use a local HTTP server as explained in the media lesson. Python users can run py -m http.server 8000 on Windows or python3 -m http.server 8000 on macOS/Linux, then visit http://localhost:8000.

All sample personal data is fictional. Forms use GET to navigate to practice-result.html and do not send/store messages; values appear in the URL. Do not use real sensitive data. No CSS, JavaScript, backend, or accounts are required. Image selection is demonstrated at a fixed slot size; full visual responsiveness belongs to CSS.

Review rationale: native headings and regions describe meaning; relative links preserve portability; table headers identify data relationships; labels and names serve different form roles; captions/transcript provide media equivalents; advanced pages use native disclosures and constrained local embedding.

Audit template: page | test | expected | observed | defect | repair | retest | limitation. Fill this with your own evidence. Completion does not grant production access; contribution readiness requires technical-team review.
