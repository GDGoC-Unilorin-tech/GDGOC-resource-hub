# Portfolio audit worksheet

Complete this with your own observations. These are not pre-recorded passing results.

Browser/version:
Date:
Viewport sizes:

| Page | Check and steps | Expected | Observed | Status | Repair | Retest |
| --- | --- | --- | --- | --- | --- | --- |
| index.html | Navigation, skip link, responsive image selection | | | Not tested | | |
| about.html | Headings, navigation, image alternative | | | Not tested | | |
| projects.html | Video, timed text, transcript, three FAQs | | | Not tested | | |
| learning-log.html | Table headers, dates, quotations, code | | | Not tested | | |
| contact.html | Labels, grouped choices, invalid and valid entries | | | Not tested | | |
| practice-result.html | Static-form limitation and return navigation | | | Not tested | | |
| project-notes.html | Titled embed, direct link, backend boundary explanation | | | Not tested | | |
| frame-note.html | Document context and readable note | | | Not tested | | |

Record a deliberately introduced defect in a backup, the repair in saved source, and the retest.
State which automated tools you used and which checks you did not perform.
Record remaining CSS layout work and other limitations without claiming complete accessibility.
