export const categories = ["all", "web", "design"];
export function validProjects(value) {
  if (!Array.isArray(value)) return false;
  const ids = new Set();
  for (const item of value) {
    if (item === null || typeof item !== "object" || typeof item.id !== "string" || item.id.trim() === "" || ids.has(item.id) || typeof item.title !== "string" || item.title.trim() === "" || !["web", "design"].includes(item.category)) return false;
    ids.add(item.id);
  }
  return true;
}
export function selectProjects(projects, state) {
  const query = state.query.trim().toLowerCase();
  const matches = projects.filter(item => (state.category === "all" || item.category === state.category) && item.title.toLowerCase().includes(query));
  return state.sort === "title" ? [...matches].sort((a, b) => a.title.localeCompare(b.title)) : matches;
}
