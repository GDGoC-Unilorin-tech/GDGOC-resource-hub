const items = document.querySelectorAll("li[data-category]");
const categories = ["all", "web", "design"];
function applyFilter(category) {
  let count = 0;
  for (const item of items) {
    const visible = category === "all" || item.dataset.category === category;
    item.hidden = !visible;
    if (visible) count = count + 1;
  }
  for (const value of categories) {
    document.querySelector(`#${value}`).setAttribute("aria-pressed", String(value === category));
  }
  document.querySelector("#status").textContent = `${count} projects`;
}
for (const category of categories) {
  document.querySelector(`#${category}`).addEventListener("click", function () {
    applyFilter(category);
  });
}
applyFilter("all");
